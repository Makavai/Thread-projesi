package yazlab2;

import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Altis extends Thread {
    
    private ArrayList<Sunucu> sun=new ArrayList<Sunucu>();
    public Altis(ArrayList<Sunucu> sunu){
        sun=sunu;
    }
    
    public void run(){
        boolean kont=true;
        while(kont){
            for(int i=1;i<sun.size();i++){
            synchronized(sun.get(i)){
                if(sun.get(i).getislimit()>sun.get(i).getislem()&&sun.get(0).getislem()>0){
                    Random ra=new Random();
                    int r=ra.nextInt(sun.get(i).getiskabul())+1;
                    sun.get(i).setislem(sun.get(i).getislem()+r);
                    if(sun.get(i).getislem()>sun.get(i).getislimit()){
                        r=r-(sun.get(i).getislem()-sun.get(i).getislimit());
                        sun.get(i).setislem(sun.get(i).getislimit());   
                    }
                    sun.get(0).setislem(sun.get(0).getislem()-r);
                }
                sun.get(i).setKapas((float)(((float)sun.get(i).getislem()/(float)sun.get(i).getislimit())*100.00));
            }
            if(sun.get(i).isTdur()){
               kont=false; break;               
            }
            }
            try {
                Thread.sleep(sun.get(1).getiskasu()-sun.size());
            } catch (InterruptedException ex) {
                Logger.getLogger(Istekal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }    
}
