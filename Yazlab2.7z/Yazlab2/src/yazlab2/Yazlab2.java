package yazlab2;

import java.util.ArrayList;
import java.util.Random;

public class Yazlab2 {

    public static void main(String[] args) {
// THREAD BEKLEME        Thread.sleep(50);
        ArrayList<Sunucu> snclar=new ArrayList<Sunucu>();
        Sunucu ana=new Sunucu();//Sunucu(10000,100,200);
        snclar.add(ana);
        snclar.add(new Sunucu(ana,5000,50,300)); snclar.add(new Sunucu(ana,5000,50,300));
        Istekal aia=new Istekal(ana);
        Istekdon aid=new Istekdon(ana);
        aia.start(); 
        aid.start();
        Sunbas al1=new Sunbas(snclar);   
        al1.start();
        Sunkont asd=new Sunkont(snclar);
        asd.start();
        Kapasite yaz=new Kapasite(snclar);
        yaz.start();
    }
}
