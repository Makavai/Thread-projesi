package yazlab2;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Sunkont extends Thread {
    
    private ArrayList<Sunucu> snc=new ArrayList<Sunucu>();
    public Sunkont(ArrayList<Sunucu> gel){
        snc=gel;
    }
 
    public void run(){
        while(true){
            for(int i=1;i<snc.size();i++){
                if(snc.size()>3&&snc.get(i).getislem()==0){
                    for(int j=1;j<snc.size();j++)
                        snc.get(j).setTdur(true);
                    try {
                        Thread.sleep(snc.get(i).getissure()+100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Sunkont.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    snc.remove(i);
                    for(int j=1;j<snc.size();j++)
                        snc.get(j).setTdur(false);
                    Sunbas as=new Sunbas(snc);
                    as.start();  break;
                }
                if(snc.get(i).getKapas()>70){
                    int islem=snc.get(i).getislem()/2;
                    snc.get(i).setislem(islem);
                    snc.add(new Sunucu(snc.get(0),5000,50,300));
                    snc.get(snc.size()-1).setislem(islem);
                    for(int j=1;j<snc.size();j++)
                        snc.get(j).setTdur(true);
                    try {
                        Thread.sleep(snc.get(i).getissure()+100);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Sunkont.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    for(int j=1;j<snc.size();j++)
                        snc.get(j).setTdur(false);
                    Sunbas as=new Sunbas(snc);
                    as.start();
                    break;
                }
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(Sunkont.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
        }
    }

