package yazlab2;

public class Sunucu {
    private int islimit;// Ana 10.000 Alt 5.000 EN SONDA DÜZELT ŞİMDİLİK 1000 DE ÇALIŞIYORUM
    
    private int iskabul;// 100        50
    private int iskasu;//  200ms        200ms
    private float kapas;
    private int issure;//  200ms        300ms
    private int islem;
    //private int isdön;//   50         50
    private Sunucu ansu;
    private boolean tdur;
    public Sunucu(){
        islimit=10000;
        iskabul=200;
        issure=200;
        islem=0;
        iskasu=200;
        ansu=null;
        kapas=0;
        tdur=false;
    }
    public Sunucu(Sunucu suu,int a,int b,int c){
        ansu=suu;
        islimit=a;
        iskabul=b;
        issure=c;
        islem=0;
        iskasu=200;
        kapas=0;
        tdur=false;
    }

    public int getislimit() {
        return islimit;
    }
    public void setislimit(int islimit) {
        this.islimit = islimit;
    }
    public int getiskabul() {
        return iskabul;
    }
    public void setiskabul(int iskabul) {
        this.iskabul = iskabul;
    }
    public int getissure() {
        return issure;
    }
    public void setissure(int issure) {
        this.issure = issure;
    } 
    public int getislem() {
        return islem;
    }
    public void setislem(int islem) {
        this.islem = islem;
    }
    public int getiskasu() {
        return iskasu;
    }
    public void setiskasu(int iskasu) {
        this.iskasu = iskasu;
    }
    public Sunucu getAnsu() {
        return ansu;
    }
    public void setAnsu(Sunucu ansu) {
        this.ansu = ansu;
    }
    public float getKapas() {
        return kapas;
    }
    public void setKapas(float kapas) {
        this.kapas = kapas;
    }
    public boolean isTdur() {
        return tdur;
    }
    public void setTdur(boolean tdur) {
        this.tdur = tdur;
    }
    
}
