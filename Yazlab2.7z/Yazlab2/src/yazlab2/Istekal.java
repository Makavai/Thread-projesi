package yazlab2;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Istekal extends Thread {
    
    private Sunucu sun;
    public Istekal(Sunucu gels){
        sun=gels;
    }
    
    public void run(){
        while(true){
            synchronized(sun){
            if(sun.getislimit()>sun.getislem()){//getAnsu || nullsa sonrası patlıyor.
                Random ra=new Random();
                int r=ra.nextInt(sun.getiskabul())+1;
                sun.setislem(sun.getislem()+r);
            }
            if(sun.getislem()>sun.getislimit())
                sun.setislem(sun.getislimit());
            sun.setKapas((float)(((float)sun.getislem()/(float)sun.getislimit())*100.00));
            }
            try {
                Thread.sleep(sun.getiskasu());
            } catch (InterruptedException ex) {
                Logger.getLogger(Istekal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
