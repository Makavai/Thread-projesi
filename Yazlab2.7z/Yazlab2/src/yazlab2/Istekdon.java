package yazlab2;

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Istekdon extends Thread {
    
    private Sunucu sun;
    public Istekdon(Sunucu gels){
        sun=gels;
    }
    
    public void run(){
        while(true){
            synchronized(sun){
            if(sun.getislem()>0){
                Random ra=new Random();
                int r=ra.nextInt(50)+1;
                sun.setislem(sun.getislem()-r);
            }
            if(sun.getislem()<0)
                sun.setislem(0);
            //System.out.println("Çözülen işlemden sonra kalan işlem: "+sun.getislem());
            sun.setKapas((float)(((float)sun.getislem()/(float)sun.getislimit())*100.00));
            if(sun.isTdur())
            break;
            }
            try {
                Thread.sleep(sun.getissure());
            } catch (InterruptedException ex) {
                Logger.getLogger(Istekal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
