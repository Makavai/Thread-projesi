package yazlab2;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Sunbas extends Thread {
    
    private int snsayi;
    private ArrayList<Sunucu> snc=new ArrayList<Sunucu>();
    public Sunbas(ArrayList<Sunucu> gel){
        snc=gel;
    }

    public void run(){
        Altis alid=new Altis(snc);
        alid.start();    
        for(int i=1;i<snc.size();i++){
            Istekdon alia=new Istekdon(snc.get(i));
            alia.start();
        }
    }
            
}

