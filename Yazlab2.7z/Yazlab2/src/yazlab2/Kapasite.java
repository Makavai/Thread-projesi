package yazlab2;

import java.awt.Color;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class Kapasite extends Thread{
    
    private ArrayList<Sunucu> snc=new ArrayList<Sunucu>();
    
    public Kapasite(ArrayList<Sunucu> sunc){
        snc=sunc;
    }
    
    public void run(){
        Arayuz pen=new Arayuz();
        pen.setSs(snc);
        Color asd= new Color(200,200,200);
        pen.setBackground(asd);
        pen.setSize(1100, 1100);
        pen.setVisible(true);
        pen.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        while(true){
            pen.repaint();
            for(int i=0;i<snc.size();i++){
                
                
                System.out.println(i+". Sunucu Kapasitesi % "+snc.get(i).getKapas());
            }
            try {
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Kapasite.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
