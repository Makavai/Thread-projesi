package yazlab2;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class Arayuz extends JFrame{
    
    private ArrayList<Sunucu> ss=new ArrayList<Sunucu>();
    public Arayuz(){
        super();
    }
    
    public void paint(Graphics g){
        super.paint(g);
        for(int i=0;i<ss.size();i++){
            g.setColor(Color.black);
            g.fillRect(100,100+(i*100),609,69);
            g.drawString("Sunucu: "+(i+1),750,100+(i*100)+40);
            if(i==0)
                g.drawString("(Ana Sunucu)",810,100+(i*100)+40);
        }
        
        for(int i=0;i<ss.size();i++){
            g.setColor(Color.WHITE);
            g.fillRect(104,104+(i*100),600*(int)ss.get(i).getKapas()/100,60);
            g.setColor(Color.RED);
            g.drawString("% "+(int)ss.get(i).getKapas(),360,100+(i*100)+40);
        }
    
    }
    
    public ArrayList<Sunucu> getSs() {
        return ss;
    }
    public void setSs(ArrayList<Sunucu> ss) {
        this.ss = ss;
    }
    
}
